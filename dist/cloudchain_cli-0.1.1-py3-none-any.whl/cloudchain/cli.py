# cli.py
from .core import interactive

def main():
    interactive()

