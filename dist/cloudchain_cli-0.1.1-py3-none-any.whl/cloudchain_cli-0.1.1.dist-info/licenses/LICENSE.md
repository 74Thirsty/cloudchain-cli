CloudChain License

Copyright © 2025 Christopher Hirschauer

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to use, copy, and modify the Software for personal or commercial purposes, subject to the following conditions:
	1.	The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
	2.	The Software is provided “as is”, without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, and noninfringement. In no event shall the author be liable for any claim, damages, or other liability, whether in an action of contract, tort, or otherwise, arising from, out of, or in connection with the Software or the use or other dealings in the Software.
	3.	All rights not expressly granted are reserved by the author.

